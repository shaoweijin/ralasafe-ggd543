/**
 * Copyright (c) 2004-2011 Wang Jinbao(Julian Wong), http://www.ralasafe.com
 * Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
 */
package org.ralasafe.user;

public class GroupPart {
	private String[] name;
	
	public String[] getNames() {
		return name;
	}
	public void setNames( String[] names ) {
		this.name = names;
	}
}
